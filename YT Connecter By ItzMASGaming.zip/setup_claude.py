"""Adds the YouTube connector to EVERY Claude Desktop config it can find.

Usage:  python setup_claude.py            (auto-detect)
        python setup_claude.py "C:\\path\\to\\claude_desktop_config.json"   (extra target)
"""
import glob, json, os, sys

here = os.path.dirname(os.path.abspath(__file__))
appdata = os.environ.get("APPDATA", "")
local = os.environ.get("LOCALAPPDATA", "")

targets = []
if appdata:
    targets.append(os.path.join(appdata, "Claude", "claude_desktop_config.json"))
if local:
    # custom data folders such as Claude-Data\claude_1234 or Claude-Data
    for pat in ("Claude-Data", "Claude*"):
        targets += glob.glob(os.path.join(local, pat, "**", "claude_desktop_config.json"), recursive=True)
targets += [a for a in sys.argv[1:] if a.lower().endswith(".json")]

seen, found = set(), []
for t in targets:
    k = os.path.normcase(os.path.abspath(t))
    if k not in seen:
        seen.add(k)
        found.append(os.path.abspath(t))

# update configs that exist (plus extra paths given by hand); if none exist, create the default
existing = [t for t in found if os.path.exists(t) or t in [os.path.abspath(a) for a in sys.argv[1:]]]
if not existing and found:
    existing = [found[0]]
if not existing:
    sys.exit("Could not find a Claude config location. Pass the config path as an argument.")

for cfg_path in existing:
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, encoding="utf-8-sig") as f:
                cfg = json.load(f)
        except Exception:
            print("Skipped (could not read, left untouched):", cfg_path)
            continue
    cfg.setdefault("mcpServers", {})["youtube"] = {
        "command": sys.executable,
        "args": [os.path.join(here, "youtube_mcp.py")],
    }
    os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    print("Added YouTube connector to:", cfg_path)
