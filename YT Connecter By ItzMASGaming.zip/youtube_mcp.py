"""
YouTube connector (MCP server) for Claude - full-access edition.

Secrets live in a .env file next to this script (see .env.example):
    YOUTUBE_CLIENT_ID=...
    YOUTUBE_CLIENT_SECRET=...
    YOUTUBE_REFRESH_TOKEN=...   (written automatically by:  python youtube_mcp.py --login)

Covers the whole YouTube Data API v3 (videos, privacy, playlists, comments,
captions, subscriptions, channel settings, thumbnails, uploads) plus the
YouTube Analytics API, and has a generic `youtube_api` tool as an escape hatch
for any resource not wrapped by a dedicated tool.
"""
import functools
import json
import os
import subprocess
import sys
from typing import Any

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload
from mcp.server.fastmcp import FastMCP

# --------------------------------------------------------------------------
# Config / secrets (.env)
# --------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.path.join(HERE, ".env")
LEGACY_SECRET = os.path.join(HERE, "client_secret.json")  # optional fallback

SCOPES = [
    "https://www.googleapis.com/auth/youtube",                    # manage account
    "https://www.googleapis.com/auth/youtube.force-ssl",          # comments, captions
    "https://www.googleapis.com/auth/youtube.upload",             # uploads
    "https://www.googleapis.com/auth/yt-analytics.readonly",      # analytics
    "https://www.googleapis.com/auth/yt-analytics-monetary.readonly",  # revenue
]
AUTH_URI = "https://accounts.google.com/o/oauth2/auth"
TOKEN_URI = "https://oauth2.googleapis.com/token"


def _load_env(path: str = ENV_PATH) -> None:
    """Tiny .env reader (no extra dependency). Real env vars win over the file."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            if v and not os.environ.get(k):
                os.environ[k] = v


def _save_env(key: str, value: str, path: str = ENV_PATH) -> None:
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    new, done = [], False
    for ln in lines:
        if ln.split("=", 1)[0].strip() == key:
            new.append(f"{key}={value}")
            done = True
        else:
            new.append(ln)
    if not done:
        new.append(f"{key}={value}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(new) + "\n")
    os.environ[key] = value


_load_env()


def _client() -> tuple[str, str]:
    cid = os.environ.get("YOUTUBE_CLIENT_ID")
    sec = os.environ.get("YOUTUBE_CLIENT_SECRET")
    if (not cid or not sec) and os.path.exists(LEGACY_SECRET):
        with open(LEGACY_SECRET, encoding="utf-8") as f:
            d = json.load(f)
        d = d.get("installed") or d.get("web") or {}
        cid, sec = d.get("client_id"), d.get("client_secret")
    if not cid or not sec:
        raise RuntimeError(
            "Missing YOUTUBE_CLIENT_ID / YOUTUBE_CLIENT_SECRET. "
            "Copy .env.example to .env and fill them in."
        )
    return cid, sec


def login() -> None:
    """Interactive browser login; stores the refresh token in .env."""
    cid, sec = _client()
    cfg = {"installed": {
        "client_id": cid, "client_secret": sec,
        "auth_uri": AUTH_URI, "token_uri": TOKEN_URI,
        "redirect_uris": ["http://localhost"],
    }}
    flow = InstalledAppFlow.from_client_config(cfg, SCOPES)
    creds = flow.run_local_server(host="localhost", port=0, prompt="consent")
    if not creds.refresh_token:
        raise RuntimeError("Google did not return a refresh token. Try again.")
    _save_env("YOUTUBE_REFRESH_TOKEN", creds.refresh_token)


_CREDS: Credentials | None = None
_SERVICES: dict[tuple[str, str], Any] = {}


def _creds() -> Credentials:
    global _CREDS
    if _CREDS is None:
        rt = os.environ.get("YOUTUBE_REFRESH_TOKEN")
        if not rt:
            raise RuntimeError(
                "Not logged in. Run start.bat (or: python youtube_mcp.py --login) once."
            )
        cid, sec = _client()
        _CREDS = Credentials(
            None, refresh_token=rt, token_uri=TOKEN_URI,
            client_id=cid, client_secret=sec, scopes=SCOPES,
        )
        _CREDS.refresh(Request())
    return _CREDS


def _svc(name: str, version: str):
    key = (name, version)
    if key not in _SERVICES:
        _SERVICES[key] = build(name, version, credentials=_creds(), cache_discovery=False)
    return _SERVICES[key]


def yt():
    return _svc("youtube", "v3")


def yta():
    return _svc("youtubeAnalytics", "v2")


# --------------------------------------------------------------------------
# Tool plumbing
# --------------------------------------------------------------------------
mcp = FastMCP("youtube")


def _http_msg(e: HttpError) -> str:
    try:
        err = json.loads(e.content.decode("utf-8"))["error"]
        reasons = ",".join(x.get("reason", "") for x in err.get("errors", []))
        return f"{err.get('message', '')} [{reasons}]".strip()
    except Exception:
        return str(e)


def tool(fn):
    """Register as an MCP tool, turning exceptions into readable error dicts."""
    @functools.wraps(fn)
    def wrapper(*a, **k):
        try:
            return fn(*a, **k)
        except HttpError as e:
            hint = ""
            if e.resp.status == 403 and "insufficient" in _http_msg(e).lower():
                hint = " (token is missing a scope - run start.bat again to re-login)"
            return {"error": f"YouTube API {e.resp.status}: {_http_msg(e)}{hint}"}
        except RefreshError:
            return {"error": "Login expired or revoked. Run start.bat (or --login) again."}
        except Exception as e:  # noqa: BLE001
            return {"error": f"{type(e).__name__}: {e}"}
    return mcp.tool()(wrapper)


def _need_confirm(confirm: bool, what: str):
    if not confirm:
        return {"error": f"Refusing to {what} without confirm=true. Ask the user first."}
    return None


def _uploads_playlist() -> str:
    ch = yt().channels().list(part="contentDetails", mine=True).execute()
    return ch["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]


def _channel_id() -> str:
    return yt().channels().list(part="id", mine=True).execute()["items"][0]["id"]


def _summarize(v: dict) -> dict:
    sn, st = v.get("snippet", {}), v.get("status", {})
    stats, cd = v.get("statistics", {}), v.get("contentDetails", {})
    return {
        "id": v["id"],
        "title": sn.get("title"),
        "published": sn.get("publishedAt"),
        "privacy": st.get("privacyStatus"),
        "scheduled_publish_at": st.get("publishAt"),
        "upload_status": st.get("uploadStatus"),
        "views": stats.get("viewCount"),
        "likes": stats.get("likeCount"),
        "comments": stats.get("commentCount"),
        "duration": cd.get("duration"),
        "url": f"https://youtu.be/{v['id']}",
    }


def _videos(ids: list[str]) -> list[dict]:
    out: dict[str, dict] = {}
    for i in range(0, len(ids), 50):
        r = yt().videos().list(
            part="snippet,status,statistics,contentDetails", id=",".join(ids[i:i + 50])
        ).execute()
        for v in r.get("items", []):
            out[v["id"]] = _summarize(v)
    return [out[i] for i in ids if i in out]


# --------------------------------------------------------------------------
# Account / channel
# --------------------------------------------------------------------------
@tool
def check_access() -> Any:
    """Test the login: reports which APIs (Data, Analytics) work and the channel name."""
    res: dict[str, Any] = {}
    try:
        ch = yt().channels().list(part="snippet,statistics", mine=True).execute()["items"][0]
        res["data_api"] = "ok"
        res["channel"] = {"id": ch["id"], "title": ch["snippet"]["title"],
                          "statistics": ch["statistics"]}
    except Exception as e:  # noqa: BLE001
        res["data_api"] = f"FAILED: {e}"
    try:
        yta().reports().query(ids="channel==MINE", startDate="2020-01-01",
                              endDate="2020-01-02", metrics="views").execute()
        res["analytics_api"] = "ok"
    except Exception as e:  # noqa: BLE001
        res["analytics_api"] = f"FAILED (enable 'YouTube Analytics API' in Google Cloud?): {e}"
    return res


@tool
def get_channel() -> Any:
    """Get my channel: snippet, statistics, branding settings, upload playlist id, status."""
    r = yt().channels().list(
        part="snippet,statistics,brandingSettings,contentDetails,status,topicDetails,localizations",
        mine=True,
    ).execute()
    return r["items"][0] if r.get("items") else {}


@tool
def update_channel(
    description: str | None = None,
    keywords: str | None = None,
    default_language: str | None = None,
    country: str | None = None,
) -> Any:
    """Update channel branding text. keywords is one space-separated string. Only given fields change."""
    y = yt()
    cur = y.channels().list(part="id,brandingSettings", mine=True).execute()["items"][0]
    bs = cur["brandingSettings"]
    ch = bs.setdefault("channel", {})
    if description is not None:
        ch["description"] = description
    if keywords is not None:
        ch["keywords"] = keywords
    if default_language is not None:
        ch["defaultLanguage"] = default_language
    if country is not None:
        ch["country"] = country
    y.channels().update(part="brandingSettings", body={"id": cur["id"], "brandingSettings": bs}).execute()
    return {"ok": True}


# --------------------------------------------------------------------------
# Videos
# --------------------------------------------------------------------------
@tool
def list_my_videos(max_results: int = 25, page_token: str | None = None) -> Any:
    """List my uploads newest-first INCLUDING private/unlisted/scheduled ones.
    Each item has id, title, published, privacy (public/unlisted/private), scheduled_publish_at, views, likes, comments, duration, url."""
    y = yt()
    uploads = _uploads_playlist()
    ids: list[str] = []
    token, nxt = page_token, None
    while len(ids) < max_results:
        r = y.playlistItems().list(
            part="contentDetails", playlistId=uploads,
            maxResults=min(50, max_results - len(ids)), pageToken=token,
        ).execute()
        ids += [i["contentDetails"]["videoId"] for i in r.get("items", [])]
        nxt = r.get("nextPageToken")
        if not nxt:
            break
        token = nxt
    return {"videos": _videos(ids), "next_page_token": nxt}


@tool
def search_my_videos(query: str, max_results: int = 25) -> Any:
    """Search within my own videos by text (costs 100 quota units)."""
    r = yt().search().list(
        part="snippet", forMine=True, type="video", q=query, maxResults=min(max_results, 50)
    ).execute()
    ids = [i["id"]["videoId"] for i in r.get("items", [])]
    return {"videos": _videos(ids)}


@tool
def get_video(video_id: str) -> Any:
    """Full details of a video: snippet, content details, statistics, STATUS (privacy), topics, recording, localizations, processing."""
    r = yt().videos().list(
        part="snippet,contentDetails,statistics,status,topicDetails,recordingDetails,localizations,processingDetails",
        id=video_id,
    ).execute()
    return r["items"][0] if r.get("items") else {"error": "video not found"}


@tool
def update_video(
    video_id: str,
    title: str | None = None,
    description: str | None = None,
    tags: list[str] | None = None,
    category_id: str | None = None,
    default_language: str | None = None,
) -> Any:
    """Change a video's title, description, tags, category and/or default language. Only given fields change."""
    y = yt()
    cur = y.videos().list(part="snippet", id=video_id).execute()["items"][0]["snippet"]
    sn = {k: cur[k] for k in ("title", "description", "tags", "categoryId",
                              "defaultLanguage", "defaultAudioLanguage") if k in cur}
    if title is not None:
        sn["title"] = title
    if description is not None:
        sn["description"] = description
    if tags is not None:
        sn["tags"] = tags
    if category_id is not None:
        sn["categoryId"] = category_id
    if default_language is not None:
        sn["defaultLanguage"] = default_language
    y.videos().update(part="snippet", body={"id": video_id, "snippet": sn}).execute()
    return {"ok": True, "video_id": video_id}


@tool
def update_video_status(
    video_id: str,
    privacy: str | None = None,
    publish_at: str | None = None,
    embeddable: bool | None = None,
    public_stats_viewable: bool | None = None,
    license: str | None = None,
    made_for_kids: bool | None = None,
) -> Any:
    """Change privacy and other status flags. privacy: public | unlisted | private.
    publish_at: RFC3339 time (e.g. 2026-11-12T15:00:00Z) to schedule - the video is set private until then.
    license: youtube | creativeCommon. Only given fields change."""
    y = yt()
    cur = y.videos().list(part="status", id=video_id).execute()["items"][0]["status"]
    st = {k: cur[k] for k in ("privacyStatus", "embeddable", "license", "publicStatsViewable",
                              "selfDeclaredMadeForKids", "publishAt") if k in cur}
    if privacy is not None:
        if privacy not in ("public", "unlisted", "private"):
            return {"error": "privacy must be public, unlisted or private"}
        st["privacyStatus"] = privacy
        if privacy != "private":
            st.pop("publishAt", None)
    if publish_at is not None:
        st["privacyStatus"] = "private"
        st["publishAt"] = publish_at
    if embeddable is not None:
        st["embeddable"] = embeddable
    if public_stats_viewable is not None:
        st["publicStatsViewable"] = public_stats_viewable
    if license is not None:
        st["license"] = license
    if made_for_kids is not None:
        st["selfDeclaredMadeForKids"] = made_for_kids
    y.videos().update(part="status", body={"id": video_id, "status": st}).execute()
    return {"ok": True, "video_id": video_id, "status": st}


@tool
def delete_video(video_id: str, confirm: bool = False) -> Any:
    """PERMANENTLY delete a video. Requires confirm=true."""
    if (e := _need_confirm(confirm, "delete a video")):
        return e
    yt().videos().delete(id=video_id).execute()
    return {"ok": True, "deleted": video_id}


@tool
def rate_video(video_id: str, rating: str = "like") -> Any:
    """Rate a video: like | dislike | none."""
    yt().videos().rate(id=video_id, rating=rating).execute()
    return {"ok": True}


@tool
def set_thumbnail(video_id: str, image_path: str) -> Any:
    """Set a custom thumbnail from a local image file (JPG/PNG)."""
    yt().thumbnails().set(videoId=video_id, media_body=MediaFileUpload(image_path)).execute()
    return {"ok": True, "video_id": video_id}


@tool
def upload_video(
    file_path: str,
    title: str,
    description: str = "",
    tags: list[str] | None = None,
    privacy: str = "private",
    category_id: str = "22",
    made_for_kids: bool = False,
    publish_at: str | None = None,
) -> Any:
    """Upload a local video. privacy: private | unlisted | public. publish_at (RFC3339) schedules it.
    Costs ~1600 quota units."""
    status: dict[str, Any] = {"privacyStatus": privacy, "selfDeclaredMadeForKids": made_for_kids}
    if publish_at:
        status.update(privacyStatus="private", publishAt=publish_at)
    body = {
        "snippet": {"title": title, "description": description, "tags": tags or [],
                    "categoryId": category_id},
        "status": status,
    }
    req = yt().videos().insert(
        part="snippet,status", body=body,
        media_body=MediaFileUpload(file_path, chunksize=32 * 1024 * 1024, resumable=True),
    )
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    return {"ok": True, "id": resp["id"], "url": f"https://youtu.be/{resp['id']}"}


@tool
def trim_video(input_path: str, start: str, end: str, output_path: str) -> Any:
    """Cut a local video between start and end (e.g. '00:00:10' to '00:01:30') using ffmpeg. Free, runs locally."""
    subprocess.run(
        ["ffmpeg", "-y", "-i", input_path, "-ss", start, "-to", end, "-c", "copy", output_path],
        check=True,
    )
    return {"ok": True, "output": output_path}


@tool
def list_video_categories(region: str = "US") -> Any:
    """List video category ids/names for a region code (for update_video category_id)."""
    r = yt().videoCategories().list(part="snippet", regionCode=region).execute()
    return [{"id": i["id"], "title": i["snippet"]["title"]} for i in r.get("items", [])]


# --------------------------------------------------------------------------
# Playlists
# --------------------------------------------------------------------------
@tool
def list_playlists(max_results: int = 50, page_token: str | None = None) -> Any:
    """List my playlists."""
    r = yt().playlists().list(
        part="snippet,status,contentDetails", mine=True,
        maxResults=min(max_results, 50), pageToken=page_token,
    ).execute()
    return {
        "playlists": [{"id": p["id"], "title": p["snippet"]["title"],
                       "privacy": p["status"]["privacyStatus"],
                       "items": p["contentDetails"]["itemCount"]} for p in r.get("items", [])],
        "next_page_token": r.get("nextPageToken"),
    }


@tool
def create_playlist(title: str, description: str = "", privacy: str = "private") -> Any:
    """Create a playlist. privacy: private | unlisted | public."""
    r = yt().playlists().insert(
        part="snippet,status",
        body={"snippet": {"title": title, "description": description},
              "status": {"privacyStatus": privacy}},
    ).execute()
    return {"ok": True, "id": r["id"]}


@tool
def update_playlist(
    playlist_id: str, title: str | None = None,
    description: str | None = None, privacy: str | None = None,
) -> Any:
    """Edit a playlist's title, description and/or privacy."""
    y = yt()
    cur = y.playlists().list(part="snippet,status", id=playlist_id).execute()["items"][0]
    sn = {"title": cur["snippet"]["title"], "description": cur["snippet"].get("description", "")}
    st = {"privacyStatus": cur["status"]["privacyStatus"]}
    if title is not None:
        sn["title"] = title
    if description is not None:
        sn["description"] = description
    if privacy is not None:
        st["privacyStatus"] = privacy
    y.playlists().update(part="snippet,status",
                         body={"id": playlist_id, "snippet": sn, "status": st}).execute()
    return {"ok": True}


@tool
def delete_playlist(playlist_id: str, confirm: bool = False) -> Any:
    """Delete a playlist (videos stay). Requires confirm=true."""
    if (e := _need_confirm(confirm, "delete a playlist")):
        return e
    yt().playlists().delete(id=playlist_id).execute()
    return {"ok": True}


@tool
def list_playlist_items(playlist_id: str, max_results: int = 50, page_token: str | None = None) -> Any:
    """List videos in a playlist (returns playlist_item_id needed for removal)."""
    r = yt().playlistItems().list(
        part="snippet,contentDetails", playlistId=playlist_id,
        maxResults=min(max_results, 50), pageToken=page_token,
    ).execute()
    return {
        "items": [{"playlist_item_id": i["id"], "video_id": i["contentDetails"]["videoId"],
                   "title": i["snippet"]["title"], "position": i["snippet"]["position"]}
                  for i in r.get("items", [])],
        "next_page_token": r.get("nextPageToken"),
    }


@tool
def add_to_playlist(playlist_id: str, video_id: str, position: int | None = None) -> Any:
    """Add a video to a playlist (optionally at a position)."""
    sn: dict[str, Any] = {"playlistId": playlist_id,
                          "resourceId": {"kind": "youtube#video", "videoId": video_id}}
    if position is not None:
        sn["position"] = position
    r = yt().playlistItems().insert(part="snippet", body={"snippet": sn}).execute()
    return {"ok": True, "playlist_item_id": r["id"]}


@tool
def remove_from_playlist(playlist_item_id: str) -> Any:
    """Remove an entry from a playlist (use the playlist_item_id from list_playlist_items)."""
    yt().playlistItems().delete(id=playlist_item_id).execute()
    return {"ok": True}


# --------------------------------------------------------------------------
# Comments
# --------------------------------------------------------------------------
def _thread(t: dict) -> dict:
    top = t["snippet"]["topLevelComment"]
    sn = top["snippet"]
    return {
        "thread_id": t["id"], "comment_id": top["id"],
        "video_id": t["snippet"].get("videoId"),
        "author": sn["authorDisplayName"], "text": sn["textDisplay"],
        "likes": sn["likeCount"], "published": sn["publishedAt"],
        "reply_count": t["snippet"]["totalReplyCount"],
        "replies": [{"comment_id": r["id"], "author": r["snippet"]["authorDisplayName"],
                     "text": r["snippet"]["textDisplay"]}
                    for r in t.get("replies", {}).get("comments", [])],
    }


@tool
def list_comments(
    video_id: str | None = None, max_results: int = 50,
    order: str = "time", page_token: str | None = None,
    moderation_status: str = "published",
) -> Any:
    """List comment threads on one video, or on ALL my videos if video_id is omitted.
    order: time | relevance. moderation_status: published | heldForReview | likelySpam (channel-wide only)."""
    kw: dict[str, Any] = dict(part="snippet,replies", maxResults=min(max_results, 100),
                              order=order, pageToken=page_token, textFormat="plainText")
    if video_id:
        kw["videoId"] = video_id
    else:
        kw["allThreadsRelatedToChannelId"] = _channel_id()
        kw["moderationStatus"] = moderation_status
    r = yt().commentThreads().list(**kw).execute()
    return {"threads": [_thread(t) for t in r.get("items", [])],
            "next_page_token": r.get("nextPageToken")}


@tool
def post_comment(video_id: str, text: str) -> Any:
    """Post a new top-level comment on a video as my channel."""
    r = yt().commentThreads().insert(
        part="snippet",
        body={"snippet": {"videoId": video_id,
                          "topLevelComment": {"snippet": {"textOriginal": text}}}},
    ).execute()
    return {"ok": True, "thread_id": r["id"]}


@tool
def reply_to_comment(parent_comment_id: str, text: str) -> Any:
    """Reply to a comment (use the top-level comment_id)."""
    r = yt().comments().insert(
        part="snippet", body={"snippet": {"parentId": parent_comment_id, "textOriginal": text}}
    ).execute()
    return {"ok": True, "comment_id": r["id"]}


@tool
def edit_comment(comment_id: str, text: str) -> Any:
    """Edit one of my own comments."""
    yt().comments().update(
        part="snippet", body={"id": comment_id, "snippet": {"textOriginal": text}}
    ).execute()
    return {"ok": True}


@tool
def delete_comment(comment_id: str, confirm: bool = False) -> Any:
    """Delete a comment (mine, or on my videos). Requires confirm=true."""
    if (e := _need_confirm(confirm, "delete a comment")):
        return e
    yt().comments().delete(id=comment_id).execute()
    return {"ok": True}


@tool
def moderate_comment(comment_id: str, status: str, ban_author: bool = False) -> Any:
    """Moderate a comment on my video. status: published | heldForReview | rejected. ban_author only with rejected."""
    kw: dict[str, Any] = {"id": comment_id, "moderationStatus": status}
    if ban_author:
        kw["banAuthor"] = True
    yt().comments().setModerationStatus(**kw).execute()
    return {"ok": True}


@tool
def mark_comment_spam(comment_id: str) -> Any:
    """Mark a comment as spam."""
    yt().comments().markAsSpam(id=comment_id).execute()
    return {"ok": True}


# --------------------------------------------------------------------------
# Captions
# --------------------------------------------------------------------------
@tool
def list_captions(video_id: str) -> Any:
    """List caption tracks on a video."""
    r = yt().captions().list(part="snippet", videoId=video_id).execute()
    return [{"id": c["id"], "language": c["snippet"]["language"], "name": c["snippet"]["name"],
             "kind": c["snippet"]["trackKind"], "draft": c["snippet"].get("isDraft")}
            for c in r.get("items", [])]


@tool
def download_caption(caption_id: str, output_path: str | None = None, fmt: str = "srt") -> Any:
    """Download a caption track (fmt: srt | vtt | sbv). Saves to output_path if given, else returns text."""
    data = yt().captions().download(id=caption_id, tfmt=fmt).execute()
    text = data.decode("utf-8", "replace") if isinstance(data, bytes) else str(data)
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
        return {"ok": True, "saved": output_path}
    return {"text": text}


@tool
def upload_caption(video_id: str, file_path: str, language: str = "en",
                   name: str = "", is_draft: bool = False) -> Any:
    """Upload a caption/subtitle file (srt/vtt) to a video."""
    r = yt().captions().insert(
        part="snippet",
        body={"snippet": {"videoId": video_id, "language": language,
                          "name": name, "isDraft": is_draft}},
        media_body=MediaFileUpload(file_path),
    ).execute()
    return {"ok": True, "caption_id": r["id"]}


@tool
def delete_caption(caption_id: str, confirm: bool = False) -> Any:
    """Delete a caption track. Requires confirm=true."""
    if (e := _need_confirm(confirm, "delete a caption track")):
        return e
    yt().captions().delete(id=caption_id).execute()
    return {"ok": True}


# --------------------------------------------------------------------------
# Subscriptions
# --------------------------------------------------------------------------
@tool
def list_subscriptions(which: str = "mine", max_results: int = 50,
                       page_token: str | None = None) -> Any:
    """which: 'mine' = channels I subscribe to, 'subscribers' = people subscribed to me (only those who made it public)."""
    kw: dict[str, Any] = dict(part="snippet", maxResults=min(max_results, 50), pageToken=page_token)
    kw["mySubscribers" if which == "subscribers" else "mine"] = True
    r = yt().subscriptions().list(**kw).execute()
    return {"items": [{"id": i["id"], "title": i["snippet"]["title"],
                       "channel_id": i["snippet"]["resourceId"]["channelId"]}
                      for i in r.get("items", [])],
            "total": r.get("pageInfo", {}).get("totalResults"),
            "next_page_token": r.get("nextPageToken")}


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------
@tool
def analytics_report(
    start_date: str, end_date: str,
    metrics: str = "views,estimatedMinutesWatched,averageViewDuration,subscribersGained,likes,comments",
    dimensions: str | None = None, filters: str | None = None,
    sort: str | None = None, max_results: int | None = None,
) -> Any:
    """YouTube Analytics query for my channel. Dates are YYYY-MM-DD.
    Examples: dimensions='day'; dimensions='video' sort='-views' max_results=10;
    filters='video==VIDEO_ID'; dimensions='country'; dimensions='insightTrafficSourceType'.
    Revenue metrics (estimatedRevenue) work only on monetized channels."""
    kw: dict[str, Any] = dict(ids="channel==MINE", startDate=start_date,
                              endDate=end_date, metrics=metrics)
    for k, v in (("dimensions", dimensions), ("filters", filters),
                 ("sort", sort), ("maxResults", max_results)):
        if v is not None:
            kw[k] = v
    r = yta().reports().query(**kw).execute()
    cols = [c["name"] for c in r.get("columnHeaders", [])]
    return {"columns": cols, "rows": r.get("rows", [])}


# --------------------------------------------------------------------------
# Generic escape hatch: anything else in the YouTube Data API v3
# --------------------------------------------------------------------------
_RESOURCES = {
    "activities", "captions", "channelBanners", "channelSections", "channels",
    "commentThreads", "comments", "i18nLanguages", "i18nRegions", "members",
    "membershipsLevels", "playlistImages", "playlistItems", "playlists", "search",
    "subscriptions", "videoAbuseReportReasons", "videoCategories", "videos", "watermarks",
}


@tool
def youtube_api(resource: str, method: str, params: dict | None = None,
                body: dict | None = None, confirm: bool = False) -> Any:
    """Call ANY YouTube Data API v3 method directly, e.g.
      resource='channelSections', method='list', params={'part':'snippet','mine':true}
      resource='members', method='list', params={'part':'snippet','mode':'all_current'}
    params = query parameters; body = JSON request body. No file uploads here (use the dedicated tools).
    Methods named delete* or report* need confirm=true."""
    if resource not in _RESOURCES:
        return {"error": f"unknown resource. Choose from: {sorted(_RESOURCES)}"}
    if method.startswith("_") or method in ("execute",):
        return {"error": "invalid method"}
    if method.lower().startswith(("delete", "report")) and (e := _need_confirm(confirm, f"call {resource}.{method}")):
        return e
    fn = getattr(getattr(yt(), resource)(), method, None)
    if fn is None:
        return {"error": f"{resource} has no method '{method}'"}
    kw = dict(params or {})
    if body is not None:
        kw["body"] = body
    r = fn(**kw).execute()
    return r if r else {"ok": True}


if __name__ == "__main__":
    if "--login" in sys.argv:
        login()
        print("Login OK. Refresh token saved to .env")
    else:
        mcp.run()
