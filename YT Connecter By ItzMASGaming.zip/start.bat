@echo off
cd /d "%~dp0"
title YouTube connector setup

where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed. Install it from https://www.python.org/downloads/
  echo IMPORTANT: tick "Add python.exe to PATH" in the installer, then run this again.
  pause
  exit /b
)

if not exist .env (
  echo.
  echo .env is missing. Copy .env.example to .env and put your
  echo YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET in it. See README.txt.
  pause
  exit /b
)

echo Installing requirements...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Install failed.
  pause
  exit /b
)

echo.
echo A browser will open. Log in to your YouTube account and allow ALL requested access.
python youtube_mcp.py --login
if errorlevel 1 (
  echo Login failed.
  pause
  exit /b
)

python setup_claude.py

echo.
echo DONE. Now fully close Claude Desktop (right-click tray icon, Quit) and open it again.
pause
