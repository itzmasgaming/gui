YOUTUBE CONNECTOR FOR CLAUDE DESKTOP (Windows) - full access edition

WHAT IT CAN DO (35 tools)
  Videos      list (with privacy status), search, details, edit title/description/tags,
              change privacy / schedule publish, upload, thumbnails, rate, delete
  Playlists   list, create, edit, delete, add/remove videos
  Comments    list (one video or whole channel), post, reply, edit, delete, moderate, spam
  Captions    list, download, upload, delete
  Channel     details, edit description/keywords, subscriptions
  Analytics   views, watch time, subscribers, traffic sources, countries, revenue...
  Anything else in the YouTube Data API via the generic "youtube_api" tool.
  Destructive actions (delete_*) refuse to run unless confirm=true.

SETUP
1. https://console.cloud.google.com -> your project -> APIs & Services -> Library.
   Enable BOTH:  "YouTube Data API v3"  and  "YouTube Analytics API".
2. OAuth consent screen: add your Google email under Test users.
   Tip: while the app is in "Testing", Google expires the login every 7 days.
   Click "Publish app" to stop that (you can ignore the unverified-app warning).
3. Credentials -> OAuth client ID -> Desktop app.
4. Copy .env.example to .env and fill in YOUTUBE_CLIENT_ID and YOUTUBE_CLIENT_SECRET.
   (Leave YOUTUBE_REFRESH_TOKEN empty - login fills it in.)
5. Double-click start.bat. A browser opens - allow ALL the permissions.
6. Fully quit and reopen Claude Desktop.
7. Ask Claude to run "check_access" to confirm everything works.

Secrets live ONLY in .env. Do not share that file.
Trimming needs ffmpeg installed: https://ffmpeg.org
